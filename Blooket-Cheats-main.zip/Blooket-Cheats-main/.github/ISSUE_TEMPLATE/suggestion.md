---
name: Suggestion
about: Give a cheat or script idea
title: 'IDEA: Script idea name'
labels: enhancement
assignees: ''

---

Gamemode (if any): 

Cheat Function:

Specifics/Alternatives:
