---
name: Skid Report
about: Report someone stealing our scripts or violating the license
title: 'SKID: <skid github account name here>'
labels: skid
assignees: Minesraft2

---

Link to skid:

Cheat(s) stolen:
