# Santa's Workshop Cheats

## [Remove Distractions](removeDistractions.js)
Removes all enemy distractions

## [Set Toys](setToys.js)
Sets amount of toys

## [Set Toys Per Question](setToysPerQ.js)
Sets amount of toys per question

## [Swap Toys](swapToys.js)
Brings up the player select page to swap with someone