# Crazy Kingdom Cheats

## [Choice ESP](choiceESP.js)
Shows you what will happen if you say Yes or No
## [Choice ESP Loop](choiceESPLoop.js)
Choice ESP but it infinitely loops

## [Disable Toucan](disableToucan.js)
Never pay taxes

## [Max Stats](maxStats.js)
Sets all resources to the max

## [Set Guests](setGuests.js)
Sets the amount of guests you've seen

## [Skip Guest](skipGuest.js)
Skips the current guest