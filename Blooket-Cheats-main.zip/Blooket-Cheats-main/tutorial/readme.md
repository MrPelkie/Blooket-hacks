# Import Bookmarklets Tutorial
## Select the browser you are using
### [Opera GX](OperaGX.md)
### [Microsoft Edge](MicrosoftEdge.md)
### [Google Chrome](GoogleChrome.md)